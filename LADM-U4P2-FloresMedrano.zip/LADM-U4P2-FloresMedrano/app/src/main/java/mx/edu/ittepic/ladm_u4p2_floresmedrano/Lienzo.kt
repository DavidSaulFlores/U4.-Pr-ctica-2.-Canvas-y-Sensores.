package mx.edu.ittepic.ladm_u4p2_floresmedrano

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class Lienzo(p: MainActivity) : View(p) {
    var px = 400f
    var dia = true

    override fun onDraw(c : Canvas) {
        var p = Paint()

        if(dia) {
            c.drawColor(Color.rgb(102, 204, 255))
            p.color = Color.rgb(51, 204, 51)
            p.style = Paint.Style.FILL
            c.drawCircle(400f, 2500f, 1080f, p)
        } else {
            c.drawColor(Color.rgb( 0, 0, 102))
            //Lampara
            c.drawBitmap(BitmapFactory.decodeResource(resources, R.drawable.lampara), 0f, 600f, p)
            //Genio
            c.drawBitmap(BitmapFactory.decodeResource(resources, R.drawable.genio), 400f, 400f, p)
        }
        //Aladdin
        c.drawBitmap(BitmapFactory.decodeResource(resources, R.drawable.aladdin), px, 1000f, p)
    }
}