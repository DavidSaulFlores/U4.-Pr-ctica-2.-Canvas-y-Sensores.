package mx.edu.ittepic.ladm_u4p2_floresmedrano

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity(), SensorEventListener {
    lateinit var lienzo : Lienzo
    lateinit var sensorManager : SensorManager

    override fun onCreate(savedInstanceState: Bundle?) {
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorManager.registerListener(this,
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager.registerListener(this,
            sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY), SensorManager.SENSOR_DELAY_NORMAL)
        super.onCreate(savedInstanceState)
        lienzo = Lienzo(this)
        setContentView(lienzo!!)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) { }
    override fun onSensorChanged(event: SensorEvent) {
        var px = event.values[0]

        if(event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            if(lienzo.px >= 1050f){
                lienzo.px = -600f
            }else if (lienzo.px <= -600f){
                lienzo.px = 1050f
            }
            lienzo.px = lienzo.px + (-px)
        }
        if(event.sensor.type == Sensor.TYPE_PROXIMITY) {
            lienzo.dia = (event.values[0] >= 5f)
        }

        lienzo.invalidate()
    }
}
